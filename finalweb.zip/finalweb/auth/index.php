<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<form method="POST" action="auth.php">
		<input type="text" name="username" placeholder="username"> <br>
		<input type="password" name="password" placeholder="Password"> <br>
		<input type="submit" name="kirim" value="Login">
	</form>
</body>
</html>