<!-- <?php
	session_start();
	if (isset($_POST['kirim'])) {
		include '../config/connection.php';
		$username = $_POST['username'];
		$password = $_POST['password'];
		$data = mysqli_query($connection, "SELECT * from user where username = '$username' and password = '$password' limit 1 ") or die(mysqli_error($connection));
		$cek = mysqli_num_rows($data);
		if ($cek > 0) {
			header('location: ../index.php');
			$_SESSION['username'] = $username;
			$_SESSION['isLogin'] = true;
		}
		else{
			echo "username or password is not valid";
		}
	}
?>  -->

<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	</head>
	<body>
	 
	<?php
	$username= $_POST['username'];
	$password=$_POST['pass'];
	$DB_NAME = 'finalweb';
	$DB_HOST = 'localhost';
	$DB_USER = 'root';
	$DB_PASS = '60900117019';
	$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if (mysqli_connect_errno()) { 
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
	}
	$query = "SELECT * FROM user WHERE username='$username' and password='$password'";
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
	if($result->num_rows > 0) {
	include_once("home.php");
	
	}
	else { 
	   echo"<script>alert('Username/password it's not valid'); window.location='index.php'</script>";	
	}
	?>
		
	</body>
	</html>