<?php
	session_start();
	if (!$_SESSION['isLogin']) {
		header('location: auth/index.php');
	}
	else{
		include 'config/connection.php';
		$username = $_SESSION['username'];
		$data = mysqli_query($connection, "SELECT * from user where username = '$username' limit 1 ");
		$biodata = mysqli_fetch_array($data);

	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Testing</title>
</head>
<body>
	<img src="asset/img/<?= $biodata['foto'] ?>">
	<h2>Selamat Datang </br> <h4> <?= $biodata['nama'] ?> <a href="auth/logout.php">logout</a> </h4> </h2>
	 <table border="1" cellspacing="2" cellpadding="2">  
		<thead>
			<td>Pendidikan</td>
			<td>Tahun Masuk</td>
			<td>Tahun Selesai</td>
			<td>Pengalaman Organisasi</td>
		</thead>
		<tbody>
			<?php
				$username = $_SESSION['username'];
				$pendidikan = mysqli_query($connection, "SELECT * FROM pendidikan where username = '$username' ");
				while ($pend = mysqli_fetch_array($pendidikan)) {
					?>
							<td> <?= $pend['ket'] ?> </td> </br>
							<td> <?= $pend['thn_masuk'] ?> </td> </br>
							<td> <?= $pend['tgl_selesai'] ?> </td> </br>
							<td> <?= $pend['organisasi'] ?> </td> </br>
						</tr> 

					<?php
				}
			?>
		</tbody>
	    </table> 
</body>
</html>